#import <Foundation/Foundation.h>

@interface BondSDK : NSObject

+(NSBundle*)bundle;
+(void)present;
+(void)presentAppointmentScheduler;
+(void)setStagingMode;

@end
