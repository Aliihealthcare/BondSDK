#import "BDBaseAPIManager.h"
#import "BDDoctor.h"
#import "BDCustomer.h"
#import "BDTransaction.h"

@interface BDTransactionManager : BDBaseAPIManager

-(void)initiateCallWithCompletion:(void(^)(BDTransaction *transaction, NSString *paymentMessage, NSError *error))completion doOnCall:(void(^)(BDTransaction *transaction))doOnCall;
-(void)endTransaction:(BDTransaction*)transaction;
-(void)sendStatusUpdateForTransaction:(BDTransaction*)transaction;
-(void)callMissedForReason:(NSString *)reason withPhoneNumber:(NSString *)phoneNumber requestNotification:(BOOL)requestNotification completion:(void(^)(BOOL isValidNumber, NSError *error))completion;
-(void)submitFeedback:(NSDictionary*)feedback forTransaction:(BDTransaction*)transaction completion:(void(^)(NSError *error))completion;

@end
