#import "BDModel.h"
#import <Pusher/Pusher.h>
#import "BDTransactionStatus.h"
#import "BDDoctor.h"

#define kTransactionKey @"transaction"

@interface BDTransaction : BDModel

@property(nonatomic, strong) BDTransactionStatus     *status;
@property(nonatomic, strong) NSNumber                *transactionId;
@property(nonatomic, strong) BDDoctor                *doctor;
@property(nonatomic, strong) NSString                *openTokSessionId;
@property(nonatomic, strong) NSString                *openTokToken;

@property(nonatomic, strong) NSDictionary            *lastPayload;
@property(nonatomic, strong) PTPusherPresenceChannel *channel;

@end
