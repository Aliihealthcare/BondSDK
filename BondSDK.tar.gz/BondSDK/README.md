Add  the cocoapod 'BondSDK' to your Podfile:

`pod 'BondSDK'`

Run a pod install from your terminal, or from CocoaPods.app.

Add the 'BondSDKID' key to your Info plist file, and give your app a simple name to identify itself to Bond.
