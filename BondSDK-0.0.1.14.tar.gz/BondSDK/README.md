Add  the cocoapod 'BondSDK' to your Podfile:

`pod 'BondSDK'`

Run a pod install from your terminal, or from CocoaPods.app.

E-mail sdk@bondintelligentcare.com to request an SDK ID. Once you have an ID, add it to your Info plist file as 'BondSDKID'.
    