#import "BDModel.h"

@interface BDAppointment : BDModel

@property(strong, nonatomic) NSString *dateString;
@property(strong, nonatomic) NSDate   *date;
@property(strong, nonatomic) NSString *firstName;
@property(strong, nonatomic) NSString *lastName;
@property(strong, nonatomic) NSString *phoneNumber;
@property(strong, nonatomic) NSString *preferredMethod;

@end
