#import "BDModel.h"

@class BDCustomer;

@interface BDConsent : BDModel

@property(nonatomic, weak) BDCustomer *customer;

@property(nonatomic, strong) NSNumber *agreedToTerms;
@property(nonatomic, strong) NSNumber *allowsCameraAndMic;
@property(nonatomic, strong) NSNumber *allowsLocation;

@end
