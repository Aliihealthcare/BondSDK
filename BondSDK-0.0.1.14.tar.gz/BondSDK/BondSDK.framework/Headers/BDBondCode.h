#import <Foundation/Foundation.h>
#import "BDModel.h"

@interface BDBondCode : BDModel

@property(nonatomic, strong) NSString *code;

@end
