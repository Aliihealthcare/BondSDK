#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@class BDNetworkEngine;

@interface BDBaseAPIManager : NSObject

+(instancetype)shared;

-(NSURL*)apiUrlWithPath:(NSString*)path;

-(void)requestPath:(NSString*)path headers:(NSDictionary*)headers bodyDictionary:(NSDictionary*)body httpMethod:(NSString*)method completionHandler:(void(^)(NSDictionary *jsonResponse, NSHTTPURLResponse *response, NSError *error))completionHandler;
-(void)requestPath:(NSString*)path bodyDictionary:(NSDictionary*)body httpMethod:(NSString*)method completionHandler:(void(^)(NSDictionary *jsonResponse, NSHTTPURLResponse *response, NSError *error))completionHandler;

@end

@interface NSMutableURLRequest(Bond)

-(void)setDefaultBondAuthorization;
-(void)setBondAuthorization;

@end

@interface NSHTTPURLResponse(Bond)

@end
