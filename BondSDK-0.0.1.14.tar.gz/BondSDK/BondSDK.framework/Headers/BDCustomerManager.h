#import "BDBaseAPIManager.h"
#import "BDCustomer.h"

@interface BDCustomerManager : BDBaseAPIManager

-(void)authenticateWithEmail:(NSString*)email password:(NSString*)password completion:(void(^)(NSError *error))completion;
-(void)authenticateWithCustomerId:(NSString*)customerId completion:(void(^)(NSError *error))completion;

-(void)emailExists:(NSString *)emailAddress completion:(void(^)(BOOL exists, NSError *error))completion;
-(void)createCustomer:(BDCustomer*)customer completion:(void(^)(NSError *error))completion;
-(void)updateCustomer:(BDCustomer*)customer withCompletion:(void(^)(NSError *error, BOOL updatedCard))completion;

-(void)resetPassword:(NSString *)emailAddress completion:(void(^)(NSError *error))completion;

@end
