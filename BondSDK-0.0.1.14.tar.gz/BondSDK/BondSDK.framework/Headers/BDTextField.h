#import <UIKit/UIKit.h>
#import "BDValidatingControl.h"
#import "BDButtonBackground.h"

typedef enum : NSUInteger {
    BDTextFieldAccessoryNone,
    BDTextFieldAccessorySpinner,
    BDTextFieldAccessoryValid,
    BDTextFieldAccessoryInvalid
} BDTextFieldAccessory;

@interface BDTextField : UITextField<BDValidatingControl>

@property(nonatomic, strong) IBOutletCollection(BDTextField) NSArray *clearFieldsWhenChanged;
@property(nonatomic, strong) IBOutletCollection(BDTextField) NSArray *validateFieldsWhenValidated; //Calls validate on these other fields when this field is changed.
@property(nonatomic, strong) IBOutlet      UIView    *nextField; //When editing completes, this field will become first responder.
@property(nonatomic, strong) IBOutlet      BDButtonBackground    *buttonBackground;

@property(nonatomic, strong) IBInspectable NSString  *targetProperty; //For validation and value binding.
@property(nonatomic, strong) IBInspectable NSString  *keyPathForInitialValue; //Overrides target
@property(nonatomic, assign) IBInspectable BOOL       dontBindInitialValue; //Overrides target
@property(nonatomic, assign) IBInspectable BOOL       disableIfPopulated; //Overrides target
@property(nonatomic, assign) IBInspectable BOOL       hidesAccessory;
@property(nonatomic, assign) IBInspectable BOOL       hidesInputAccessoryView;
@property(nonatomic, assign) IBInspectable BOOL       hidesValidationMessage;
@property(nonatomic, strong) IBInspectable NSString  *remoteValidationMessage;
@property(nonatomic, assign) IBInspectable NSUInteger maxChars; //For validation and value binding.
@property(nonatomic, strong) IBInspectable NSString  *message;
@property(nonatomic, assign) IBInspectable UIColor   *placeholderColor;


@property(nonatomic, assign) BOOL shouldContinueAfterValidation; // Set by controllers to track if remote validation was triggered from a close event on the last field.

@property (nonatomic, readonly) BOOL exitedFromKeyboard;

@property(nonatomic) BDTextFieldAccessory accessory;
-(void)setAccessory:(BDTextFieldAccessory)accessory animate:(BOOL)animate;

-(void)updateTarget;
-(void)updateField;

@end
