#include <UIKit/UIKit.h>

@protocol BDValidatingControl

@property(nonatomic, weak)     NSObject *target;         //If BDModelValidatable, will use for validation
@property(nonatomic, strong)   IBInspectable NSString *targetProperty; //For validation and value binding.
@property(nonatomic, readonly) BOOL      isValid;
@property(nonatomic, readonly) NSString *longValidationMessage;
@property(nonatomic, readonly) NSString *shortValidationMessage;
-(void)validate;

@end
