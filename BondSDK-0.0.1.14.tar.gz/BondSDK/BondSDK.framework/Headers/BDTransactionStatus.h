#import "BDModel.h"

@interface BDTransactionStatus : BDModel

@property(nonatomic, strong) NSNumber *muted;

@end
