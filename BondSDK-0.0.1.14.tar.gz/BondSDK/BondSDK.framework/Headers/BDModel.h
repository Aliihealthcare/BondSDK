#import <Foundation/Foundation.h>

FOUNDATION_EXPORT NSString *const BDModelRemoteValidationRequired;

@protocol BDModelValidatable

+(NSDictionary*)longValidationMessages;
+(NSDictionary*)shortValidationMessages;
+(NSDictionary*)longPropertyNames;
-(NSString*)validationMessageForKey:(NSString*)key longMessage:(BOOL)longMessage; //If valid, will return nil.
-(NSDictionary*)validationMessages;

@end


@interface BDModel : NSObject<NSCopying, BDModelValidatable>

+(instancetype)newWithDictionary:(NSDictionary*)dictionary;

+(NSArray*)copies;
+(NSString*)idKey;
+(NSDictionary*)copiesDictionary; // camel : json
-(instancetype)initWithDictionary:(NSDictionary*)dictionary;
@property NSDictionary *dictionary;

#pragma mark - Validation
-(NSArray*)validates;
-(NSArray*)validatesYes; //For NSNumbers, validates not null and .boolValue is YES
-(NSArray*)validatesPresence;

//conventional validation methods may be added called `-(NSString*)validate${Key}`

@end
