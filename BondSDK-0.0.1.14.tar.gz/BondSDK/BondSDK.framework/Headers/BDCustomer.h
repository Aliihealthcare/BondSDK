#import <Foundation/Foundation.h>
#import "BDBondCode.h"
#import "BDModel.h"
#import "BDCardManager.h"
#import "BDConsent.h"

#define kCustomer                    @"customer"
#define kCustomerBondCode            @"bond_code"
#define kCustomerShareableBondCode   @"shareable_bond_code"

@class STPToken;

@interface BDCustomer : BDModel

+(BDCustomer*)currentCustomer;
+(void)resetCurrentCustomer;
+(void)removeCurrentCustomer;
+(void)clearCurrentCustomerAuthenticaiton;

//user info
@property (strong, nonatomic) NSNumber          *customerId;
@property (strong, nonatomic) NSString          *authenticationToken;
@property (strong, nonatomic) NSNumber          *credit;
@property (strong, nonatomic) NSString          *email;
@property (strong, nonatomic) NSNumber          *wasEmailValidatedByServer; //nil means it wasn't checked
@property (strong, nonatomic) NSString          *firstName;
@property (strong, nonatomic) NSString          *lastName;
@property (strong, nonatomic) NSString          *password; //Should only be set when creating a new customer
@property (strong, nonatomic) NSString          *passwordConfirmation; //Should only be set when creating a new customer
@property (strong, nonatomic) NSString          *stripeToken;
@property (strong, nonatomic) NSString          *stripeCustomerId; //Setting this will cause Stripe cards to be loaded
@property (strong, nonatomic) NSNumber          *agreedToTerms;
@property (strong, nonatomic) NSString          *signUpChampionCode;
@property (strong, nonatomic) NSNumber          *usesTouchId;
@property (strong, nonatomic) NSString          *championCode;
@property (strong, nonatomic) NSArray<STPCard*> *stripeCards;
@property (nonatomic)         BOOL              applePay;
@property (nonatomic, strong) STPToken          *applePayToken;

// Volitile
@property (strong, nonatomic) BDConsent *consent;

// Derived
@property (readonly) NSString           *creditCardNumberForDisplay;
@property (readonly) NSString           *fullName;

-(void)useAsCurrentCustomer;

@end
