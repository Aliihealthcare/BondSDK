//
//  PersistentUID.h
//  Swipe
//
//  Created by Patrick Childers on 1/2/16.
//  Copyright © 2016 Alii Healthcare. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PersistentUID : NSObject

+(void)UID:(void(^)(NSString*))complete;

@end
