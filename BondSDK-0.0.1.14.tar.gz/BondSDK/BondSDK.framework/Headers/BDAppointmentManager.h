#import "BDBaseAPIManager.h"
#import "BDAppointment.h"

@interface BDAppointmentManager : BDBaseAPIManager

-(void)createAppointment:(BDAppointment*)appointment completion:(void(^)(NSError *error))completion;

@end
