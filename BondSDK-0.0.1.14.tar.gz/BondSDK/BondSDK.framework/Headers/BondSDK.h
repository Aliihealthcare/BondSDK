#import <Foundation/Foundation.h>
#import "BDAppointmentManager.h"
#import "BDCustomerManager.h"
#import "BDTextField.h"
#import "BDTransaction.h"
#import "BDTransactionManager.h"
#import "PersistentUID.h"

@interface BondSDK : NSObject

+(NSBundle*)bundle;
+(void)present;
+(void)presentAppointmentScheduler;
+(void)setStagingMode;

@end
