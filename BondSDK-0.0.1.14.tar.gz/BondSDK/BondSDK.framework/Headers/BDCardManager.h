#import "BDBaseAPIManager.h"

@class BDCustomer, STPCard;

@interface BDCardManager : BDBaseAPIManager

-(void)getIndex:(void(^)(NSArray<STPCard*> *cards, NSError *error))completion;
//The following methods update the current customer as well.
-(void)create:(NSString*)cardToken completion:(void(^)(NSString *card, NSError *error))completion;
-(void)destroy:(STPCard*)card completion:(void(^)(NSError *error))completion;
-(void)destroyAllCardsForCustomer:(BDCustomer*)customer withCompletion:(void(^)(NSError *error))completion;
-(void)makeDefault:(NSString*)card completion:(void(^)(NSError *error))completion;

@end
