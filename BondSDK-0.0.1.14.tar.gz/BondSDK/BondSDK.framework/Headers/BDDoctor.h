#import <Foundation/Foundation.h>
#import "BDModel.h"

@interface BDDoctor : BDModel

@property (retain, nonatomic) NSString *name;
@property (retain, nonatomic) NSString *address;
@property (retain, nonatomic) NSString *city;
@property (retain, nonatomic) NSString *hospital;
@property (retain, nonatomic) NSString *profilePhotoUrl;
@property (retain, nonatomic) NSString *state;
@property (retain, nonatomic) NSString *zipcode;

@end
